# Etapa V4 ? HC-SR04

A vers?o atual come?a em WAITING e s? executa infer?ncia ap?s START confirmado.
Use `python main.py mock --simulate-start-after 2 --simulate-clear-after 10 --duration 12`
ou substitua `mock` por `dry-run` para c?mera real sem serial. Sem simula??o,
mock/dry-run permanecem em WAITING. A API oferece `/health`, `/status`,
`/detections` e `/decision`, somente JSON.

A documenta??o abaixo descreve tamb?m o fluxo hist?rico. Para a opera??o atual,
prevalecem [TESTE_V4_HCSR04.md](../TESTE_V4_HCSR04.md),
[PINAGEM_V4.md](../PINAGEM_V4.md) e [ESTRUTURA_V4.md](../ESTRUTURA_V4.md).
N?o iniciar `../servidor.py` ou o servi?o antigo para V4: s?o legados com streaming.
Os testes atuais n?o acionam motores.

# EcoFlutuador POC - Raspberry Pi Proof of Concept

## 1. Objetivo

Esta Proof of Concept (POC) demonstra o pipeline autônomo de navegação do EcoFlutuador:
- **Câmera** → captura frames em baixa resolução (320x240)
- **Detecção** → SSD MobileNet v3 Large (COCO) identifica garrafas PET (`bottle`)
- **Decisão** → lógica de zonas (esquerda/centro/direita) determina comando
- **Serial** → envia comando ao ESP32 (`w`/`a`/`s`/`d`/`q`/`e` + newline)
- **API** → `GET /status` retorna estado atual em JSON (opcional)

**Requisitos-chave:**
- ✅ Sem streaming de vídeo/MJPEG
- ✅ Apenas dados leves (JSON) pela rede
- ✅ Modo MOCK para testar sem hardware
- ✅ Modo DRY-RUN para testar com câmera real sem enviar comandos
- ✅ Modo REAL para operação completa com ESP32
- ✅ Shutdown limpo com Ctrl+C
- ✅ Configuração 100% externa via `config.yaml`

---

## 2. Arquitetura

```
poc_raspberry/
├── config.yaml          # Configuração completa (paths, camera, modelo, serial, decisão, API)
│   # camera.backed suporta: PICAMERA2 (CSI), V4L2 (USB), ANY, DSHOW, MSMF
│   # camera.width/height/fps: resolução capturada (configurável)
│   # camera.picamera2.format e transform: configurações específicas Picamera2
│   # model.input_size: tamanho do preprocessamento (SEPARADO da resolução da câmera)
│   # decision.zones: 3 zonas proporcionais (esquerda/centro/direita) — NÃO hardcoded
├── requirements.txt     # Dependências Python
├── main.py              # Entry point: mock | dry-run | real
├── core/
│   ├── camera.py        # Captura assíncrona (thread + buffer 1) — PICAMERA2/V4L2/ANY
│   ├── detector.py      # YOLO/SSD via OpenCV DNN (input_size separado da câmera)
│   ├── decision.py      # Lógica de zonas proporcionais (esq/centro/dir) — frame_width dinâmico
│   ├── serial_link.py   # Protocolo serial RPi↔ESP32
│   └── state.py         # Dataclass DetectionState + JSON
├── api/
│   └── status_server.py # Flask mínimo: GET /status
├── mock/
│   ├── camera_mock.py   # Gera frames sintéticos com garrafa movendo
│   ├── serial_mock.py   # Simula respostas ESP32 (CMD_OK, PWR_OK)
│   └── run_mock.py      # Runner standalone do modo MOCK
├── tests/
│   └── test_decision.py # Testes unitários (decisão + protocolo + estado)
└── models/              # Coloque aqui os arquivos do modelo
    ├── frozen_inference_graph.pb
    ├── ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt
    └── coco.names
```

**Fluxo principal (loop ~10 FPS):**
```
frame = camera.get_frame()
detections = detector.detect(frame)          # ~100-200ms no RPi 4
decision = decision_engine.decide(detections) # 'w'/'a'/'d'/'s'
if mode == REAL and decision changed:
    serial.send_command(decision)
state = DetectionState.from_detection(...)
print(JSON)                                   # log terminal
status_server.update_state(state)             # para GET /status
```

---

## 3. Instalação no Raspberry Pi

### 3.1 Sistema base (Raspberry Pi OS 64-bit recomendado)
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3-opencv python3-numpy python3-serial python3-yaml python3-flask
```

### 3.2 Clonar/criar o projeto
```bash
cd ~
# Se veio de git:
git clone <repo> EcoFlutuador
cd EcoFlutuador/poc_raspberry
# Ou copie a pasta poc_raspberry para o Pi
```

### 3.3 Instalar dependências Python (se não usar apt)
```bash
pip3 install -r requirements.txt
```

### 3.4 Baixar arquivos do modelo
```bash
cd poc_raspberry/models
# Baixar do repositório OpenCV TensorFlow Object Detection API:
# https://github.com/opencv/opencv/wiki/TensorFlow-Object-Detection-API

# Arquivos necessários:
wget https://raw.githubusercontent.com/opencv/opencv/master/samples/dnn/frozen_inference_graph.pb
wget https://raw.githubusercontent.com/opencv/opencv/master/samples/dnn/ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt
wget https://raw.githubusercontent.com/opencv/opencv/master/samples/dnn/coco.names
```

> **Nota:** Os arquivos acima são exemplos. Verifique as URLs atuais no wiki do OpenCV. O modelo SSD MobileNet v3 Large COCO é o padrão.

### 3.5 Verificar câmera
```bash
# Listar câmeras disponíveis
python3 main.py --list-cameras

# Testar captura rápida
python3 -c "
import cv2
cap = cv2.VideoCapture(0)
ret, frame = cap.read()
print(f'OK: {frame.shape}' if ret else 'FALHOU')
cap.release()
"
```

### 3.6 Verificar serial (ESP32)
```bash
# Verificar a UART GPIO configurada
ls -l /dev/serial0

# Testar comunicação (ESP32 deve estar rodando ControleESP32.ino)
python3 -c "
import serial
ser = serial.Serial('/dev/serial0', 115200, timeout=1)
ser.write(b'PING\n')
print(ser.readline())
ser.close()
"
```

---

## 4. Instalação no Notebook (Desenvolvimento)

### 4.1 Windows/macOS/Linux
```bash
# Python 3.8+
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Dependências (opencv-python via pip funciona no notebook)
pip install -r requirements.txt
pip install opencv-python numpy
```

### 4.2 Modelos (opcional para MOCK)
O modo **MOCK não precisa dos arquivos do modelo**.
Para dry-run/real no notebook, baixe os modelos como no RPi (seção 3.4).

### 4.3 Câmera no notebook
```bash
python main.py --list-cameras
# Geralmente index 0 = webcam integrada
```

---

## 5. Como Colocar os Modelos

Coloque os 3 arquivos em `poc_raspberry/models/`:
```
poc_raspberry/models/
├── frozen_inference_graph.pb          # Pesos TensorFlow (~2.7 MB)
├── ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt  # Config (~30 KB)
└── coco.names                         # 80 nomes de classes (~1 KB)
```

O `config.yaml` já aponta para essa pasta. Se colocar em outro lugar, edite:
```yaml
model:
  weights: "caminho/para/frozen_inference_graph.pb"
  config: "caminho/para/ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt"
  classes: "caminho/para/coco.names"
```

**Se os arquivos não existirem**, o programa mostra mensagem clara:
```
Model files not found:
  weights: models/frozen_inference_graph.pb
  config: models/ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt
  classes: models/coco.names

Please download the SSD MobileNet v3 Large COCO model...
```

---

## 6. Como Executar MOCK (Sem Hardware)

Testa toda a lógica de decisão, FPS, JSON output no notebook **sem câmera nem ESP32**.

```bash
cd poc_raspberry

# Execução padrão: 100 frames @ 10 FPS, log JSON no terminal
python -m mock.run_mock

# Personalizado
python -m mock.run_mock --frames 200 --fps 10 --log-level DEBUG

# Modo CI (sem output JSON por frame, só resumo final)
python -m mock.run_mock --frames 100 --quiet --log-level WARNING
```

**Saída esperada (exemplo):**
```json
{"timestamp": 1234567890.123, "level": "INFO", "logger": "mock_runner", "message": "Mock run complete: 100 frames in 10.2s = 9.8 FPS"}
{"timestamp": 1234567890.123, "level": "INFO", "logger": "mock_runner", "message": "Decisions made: ['a', 'w', 'd', 'w', 'a', ...]"}
{"timestamp": 1234567890.123, "level": "INFO", "logger": "mock_runner", "message": "Unique decisions: {'a', 'w', 'd'}"}
{"timestamp": 1234567890.123, "level": "INFO", "logger": "mock_runner", "message": "SUCCESS: All zone decisions (left/center/right) were made"}
```

**Critério de sucesso do MOCK:**
- Processa N frames sem erro
- FPS médio ≥ 5
- Todas as 3 decisões (`a`, `w`, `d`) ocorrem (garrafa visitou todas as zonas)
- Exit code 0

---

## 7. Como Executar DRY-RUN (Câmera Real, Sem ESP32)

Testa câmera + detecção + decisão **sem enviar comandos ao ESP32**.
Útil para validar detecção, posicionamento, FPS, latência.

```bash
cd poc_raspberry

# Modo dry-run (padrão seguro)
python main.py dry-run

# Com config customizado
python main.py dry-run -c config.yaml --log-level DEBUG

# Listar câmeras primeiro
python main.py dry-run --list-cameras
```

**O que acontece:**
- Abre câmera real (config.yaml → `camera.index`)
- Carrega modelo SSD MobileNet
- Roda inferência a cada frame
- Calcula decisão (`w`/`a`/`d`/`s`)
- **NÃO abre porta serial** — comandos apenas logados
- Mostra JSON por frame no terminal
- API `/status` disponível em `http://localhost:8080/status`

**Log de exemplo (DRY-RUN):**
```json
{"timestamp": 1234567890.123, "detected": true, "object": "bottle", "confidence": 0.87, "center_x": 0.32, "center_y": 0.51, "bbox": [45, 70, 60, 100], "decision": "a", "inference_ms": 156.2, "fps": 6.3}
{"timestamp": 1234567890.289, "detected": false, "object": null, "confidence": 0.0, "center_x": 0.0, "center_y": 0.0, "bbox": null, "decision": "s", "inference_ms": 142.8, "fps": 6.1}
```

---

## 8. Como Executar MODO REAL (Com ESP32)

**⚠️ ATENÇÃO:** Envia comandos reais ao ESP32. O barco **vai se mover**.

### Pré-requisitos:
1. ESP32 flashado com `ControleESP32.ino` (ou firmware compatível)
2. UART GPIO habilitada na Raspberry (`/dev/serial0`), com TX/RX cruzados e GND comum
3. Motores/ESCs conectados e alimentados
4. Área livre para teste

### Execução:
```bash
cd poc_raspberry

# Confirmação obrigatória antes de iniciar
python main.py real

# Ou com config específica
python main.py real -c config.yaml
```

**O programa pedirá confirmação:**
```
⚠️  REAL MODE: Commands WILL be sent to ESP32 via serial.
Ensure ESP32 is connected and firmware is running.
Continue? (yes/no):
```

Digite `yes` para prosseguir.

### O que acontece:
- Tudo do dry-run **mais**:
- Abre a UART configurada em `/dev/serial0`
- Envia comandos `w`/`a`/`s`/`d`/`q`/`e` + `\n` quando decisão muda
- Recebe `CMD_OK:`, `PWR_OK:`, eventos START e telemetria `TEL:` do ESP32
- Reconexão automática se serial cair

---

## 9. Como Verificar a Câmera

```bash
# Listar índices
python main.py --list-cameras
# Saída: Available cameras: /dev/video0 (index 0)

# Teste rápido de captura
python -c "
import cv2
cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)
cap.set(cv2.CAP_PROP_FPS, 10)
ret, frame = cap.read()
print(f'OK: {frame.shape} - {frame.dtype}' if ret else 'FALHOU')
cap.release()
"

# Verificar FPS real
python -c "
import cv2, time
cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)
cap.set(cv2.CAP_PROP_FPS, 10)
t0 = time.time()
for _ in range(30):
    cap.read()
print(f'FPS real: {30/(time.time()-t0):.1f}')
cap.release()
"
```

---

## 9. Como Alterar a Resolução da Câmera

A resolução da câmera é **totalmente configurável** pelo `config.yaml`. Não é hardcoded no código.

### Como alterar:

1. Abra `config.yaml`
2. Altere `width` e `height` dentro da seção `camera:`
3. Salve o arquivo
4. Execute `python main.py dry-run`
5. Confira no log a **resolução real** (pode diferir da solicitada se o sensor não suportar)
6. Verifique FPS e `inference_ms`

### Exemplo — mudar de 320x240 para 1280x720:

```yaml
camera:
  backend: "PICAMERA2"  # ou "V4L2" para câmera USB
  width: 1280
  height: 720
  fps: 10
  buffer_size: 1
```

### Resoluções recomendadas para Raspberry Pi 5:

| Resolução | Uso | Observação |
|-----------|-----|------------|
| 320x240 | Mínimo, máxima FPS | Bom para testes rápidos |
| 640x480 | Equilíbrio FPS/precisão | Recomendado para início |
| 1280x720 | Boa precisão | FPS moderado no RPi 5 |
| 1920x1080 | Máxima qualidade | FPS pode ser menor |

**Importante:** Nem toda resolução arbitrária é suportada pelo sensor. O Picamera2 lista os modos disponíveis e ajusta automaticamente para o mais próximo suportado.

### Como listar os modos suportados pela câmera CSI:

```bash
python main.py --list-cameras
```

Isso mostra todos os modos do sensor (tamanho, formato, FPS disponíveis).

### Como funciona a separação entre resolução da câmera e input do modelo:

- `camera.width / camera.height` = resolução **capturada** pela câmera CSI
- `model.input_size` = tamanho usado no **preprocessamento** do modelo YOLO

Exemplo: a câmera captura 1920x1080, o detector redimensiona para 320x320 antes de inferir. As bounding boxes são convertidas corretamente de volta para as coordenadas do frame original (1920x1080) antes de chegar ao DecisionEngine.

### Por que a resolução não fica hardcoded na decisão:

O `DecisionEngine` calcula as zonas **proporcionalmente** à largura real do frame:
- Esquerda: 0 a 1/3 da largura
- Centro: 1/3 a 2/3 da largura
- Direita: 2/3 à largura total

Portanto, um objeto na mesma posição relativa (ex: 15% da largura) sempre gera a mesma decisão (`a`), independentemente de a câmera estar a 320px ou 1920px.

### Testar diferentes resoluções:

```bash
# MOCK com diferentes resoluções
python -m mock.run_mock --frames 30 --fps 10 --width 320 --height 240
python -m mock.run_mock --frames 30 --fps 10 --width 640 --height 480
python -m mock.run_mock --frames 30 --fps 10 --width 1280 --height 720
python -m mock.run_mock --frames 30 --fps 10 --width 1920 --height 1080
```

### Erros comuns:

| Problema | Causa | Solução |
|----------|-------|---------|
| Câmera não abre com resolução solicitada | Sensor não suporta a resolução | Use `--list-cameras` para ver modos disponíveis |
| Resolução real diferente da solicitada | Picamera2 ajusta para modo mais próximo | Verifique o log: "Picamera2 started: WxH @ FPS" |
| FPS muito baixo em resolução alta | Sensor ou processamento limitado | Reduza para 640x480 ou 1280x720 |

---

## 10. Como Verificar a Câmera

```bash
# Listar índices e modos do sensor
python main.py --list-cameras

# Testar câmera CSI no RPi
rpicam-hello -t 0

# Capturar foto de teste
rpicam-still -o camera_test.jpg

# Testar captura rápida (OpenCV)
python -c "
import cv2
cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)
cap.set(cv2.CAP_PROP_FPS, 10)
ret, frame = cap.read()
print(f'OK: {frame.shape} - {frame.dtype}' if ret else 'FALHOU')
cap.release()
"

# Verificar FPS real
python -c "
import cv2, time
cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)
cap.set(cv2.CAP_PROP_FPS, 10)
t0 = time.time()
for _ in range(30):
    cap.read()
print(f'FPS real: {30/(time.time()-t0):.1f}')
cap.release()
"

```bash
# Ver portas
ls -l /dev/serial0 /dev/ttyAMA* 2>/dev/null

# Testar comunicação manual
python -c "
import serial, time
ser = serial.Serial('/dev/serial0', 115200, timeout=1)
time.sleep(2)  # Wait for ESP32 reset
ser.write(b'PING\n')
print('Sent: w')
print('Response:', ser.readline().decode().strip())
ser.write(b's\n')
print('Sent: s')
print('Response:', ser.readline().decode().strip())
ser.close()
"

# Monitor contínuo (como serial monitor do Arduino)
python -c "
import serial
ser = serial.Serial('/dev/serial0', 115200, timeout=1)
print('Monitoring... Ctrl+C to stop')
try:
    while True:
        line = ser.readline().decode().strip()
        if line: print(f'ESP32: {line}')
except KeyboardInterrupt:
    pass
ser.close()
"
```

**Respostas esperadas do ESP32 (ControleESP32.ino):**
```
CMD_OK:w
CMD_OK:s
PWR_OK:1:45
PWR_OK:2:45
EVENT:START:1
TEL:{"schema":1,"uptime_ms":1000,...}
```

---

## 11. Como Interpretar os Logs

Cada linha no terminal = **um JSON válido** por frame processado.

### Campos principais:
| Campo | Tipo | Descrição |
|-------|------|-----------|
| `timestamp` | float | Unix timestamp (time.time()) |
| `detected` | bool | True se garrafa detectada |
| `object` | string/null | `"bottle"` ou null |
| `confidence` | float | 0.0 - 1.0 |
| `center_x` | float | Centro X normalizado (0.0-1.0) |
| `center_y` | float | Centro Y normalizado (0.0-1.0) |
| `bbox` | array/null | `[x, y, w, h]` em pixels |
| `decision` | string | `w`/`a`/`d`/`s`/`q`/`e` |
| `inference_ms` | float | Tempo de inferência YOLO (ms) |
| `fps` | float | FPS médio atual |

### Exemplos:

**Garrafa à esquerda (decisão = virar esquerda):**
```json
{"detected": true, "object": "bottle", "confidence": 0.91, "center_x": 0.18, "center_y": 0.52, "bbox": [20, 60, 55, 95], "decision": "a", "inference_ms": 167.3, "fps": 5.8}
```

**Garrafa no centro (decisão = avançar):**
```json
{"detected": true, "object": "bottle", "confidence": 0.84, "center_x": 0.51, "center_y": 0.48, "bbox": [110, 65, 58, 105], "decision": "w", "inference_ms": 143.7, "fps": 6.2}
```

**Nenhuma garrafa (decisão = parar - SEGURANÇA):**
```json
{"detected": false, "object": null, "confidence": 0.0, "center_x": 0.0, "center_y": 0.0, "bbox": null, "decision": "s", "inference_ms": 138.2, "fps": 6.5}
```

### Logs do sistema (logging padrão):
```
2024-01-15 10:30:45 | INFO     | __main__   | Starting pipeline in DRY-RUN mode
2024-01-15 10:30:45 | INFO     | camera     | Camera opened: 320x240 @ 10.0 FPS
2024-01-15 10:30:45 | INFO     | detector   | Model loaded: 80 classes, input (320, 320)
2024-01-15 10:30:45 | INFO     | __main__   | Target FPS: 10
2024-01-15 10:30:50 | INFO     | __main__   | FPS: 5.9 | Total frames: 30 | Inference: 156.2ms
```

---

## 12. Como Medir FPS e Latência

### FPS real (pelo log do sistema):
```bash
# O log periódico mostra FPS a cada 5 segundos (configurável)
# logging.print_fps_interval: 30  # frames
```

### Latência de inferência (por frame):
```json
"inference_ms": 156.2
```

### Métricas alvo para POC:
| Métrica | Target Mínimo | Target Ideal |
|---------|---------------|--------------|
| FPS médio | ≥ 5 | ≥ 10 |
| Inferência | < 300 ms | < 150 ms (RPi 5) / < 200 ms (RPi 4) |
| Ciclo total | < 300 ms | < 200 ms |
| CPU (1 core) | < 80% | < 60% |
| RAM | < 400 MB | < 300 MB |

### Matriz de resoluções (preencher com dados medidos no RPi):

| Resolução | FPS solicitado | FPS real | inference_ms média | Detecção | Decisão | Observação |
|-----------|----------------|----------|--------------------|----------|---------|------------|
| 640x480   | 10             | ...      | ...                | ...      | ...     | ...        |
| 1280x720  | 10             | ...      | ...                | ...      | ...     | ...        |
| 1920x1080 | 10             | ...      | ...                | ...      | ...     | ...        |

### Benchmark rápido:
```bash
# Dry-run por 30 segundos
timeout 30 python main.py dry-run --log-level WARNING 2>&1 | grep "FPS:" | tail -5
```

---

## 13. Como Realizar a Prova Física com ESP32

### Checklist pré-voo:
- [ ] ESP32 flashado com `ControleESP32.ino`
- [ ] ESP32 alimentado (USB ou bateria)
- [ ] Motores/ESCs conectados aos pinos corretos (GPIO 18, 19 no firmware)
- [ ] Bateria dos motores carregada
- [ ] Área de teste livre (piscina, tanque, lago calmo)
- [ ] Barco flutuando e estável
- [ ] Cabo USB RPi↔ESP32 conectado (ou Bluetooth se configurado)

### Sequência de teste:
```bash
# 1. Verificar serial
python main.py --list-cameras  # confirmar câmera
ls /dev/ttyUSB*                # confirmar ESP32

# 2. Dry-run para validar detecção
python main.py dry-run
# Apontar garrafa para câmera → ver decision: w/a/d/s no log
# Ctrl+C para parar

# 3. Teste real (COM CONFIRMAÇÃO)
python main.py real
# Digite 'yes' quando solicitado

# 4. Durante o teste:
#    - Mova garrafa na frente da câmera
#    - Observe decisões no terminal
#    - Verifique se motores respondem
#    - Ctrl+C para emergência (envia 's' antes de sair)
```

### Comportamento esperado:
| Posição da garrafa | Decisão | Ação do barco |
|--------------------|---------|---------------|
| Esquerda (< 33%) | `a` | Vira esquerda |
| Centro (33-66%) | `w` | Avança |
| Direita (> 66%) | `d` | Vira direita |
| Nenhuma | `s` | Para (SEGURANÇA) |

---

## 14. Como Interromper com Segurança

### Ctrl+C (SIGINT) - Recomendado:
```bash
# No terminal rodando main.py
Ctrl+C
```

**O que acontece:**
1. Signal handler captura SIGINT
2. Loop principal para
3. `pipeline.shutdown()` chamado:
   - Para thread da câmera
   - Fecha porta serial (envia `s` se estava em movimento)
   - Para API server
4. Log final com estatísticas
5. Exit code 0

### SIGTERM (systemd, Docker):
```bash
sudo systemctl stop ecoflutuador-poc
# ou
docker stop container
```
Mesmo comportamento do Ctrl+C.

### Emergência física:
- Desconectar cabo USB do ESP32
- Ou desligar chave de alimentação dos motores
- O firmware ESP32 para os motores em caso de perda de comunicação

---

## Configuração Avançada (config.yaml)

Principais ajustes para performance:

```yaml
# Ajuste de performance:
model:
  input_size: [160, 160]      # Menor = mais rápido, menos preciso
  conf_threshold: 0.5         # Maior = menos falsos positivos

# Para mais precisão (menos FPS):
model:
  input_size: [320, 320]      # Default
  conf_threshold: 0.4         # Menor = detecta mais longe

# Zonas de decisão (proporcionais ao frame_width real):
decision:
  zones: 3                    # 3 zonas: esquerda/centro/direita
  # frame_width é obtido do frame — NÃO hardcoded

# Câmera (resolução configurável):
camera:
  backend: "PICAMERA2"        # PICAMERA2 (CSI), V4L2 (USB), ANY, DSHOW, MSMF
  width: 1280
  height: 720
  fps: 10
  buffer_size: 1

# Serial:
serial:
  port: "/dev/serial0"
  auto_detect: false          # Evita abrir outro dispositivo serial por engano
```

---

## Solução de Problemas Comuns

| Problema | Causa | Solução |
|----------|-------|---------|
| `FileNotFoundError: Model files not found` | Modelos não baixados | Baixar para `models/` (seção 5) |
| `Camera opened: 640x480` (não 320x240) | Câmera não suporta resolução | Verificar `v4l2-ctl --list-formats-ext` |
| `/dev/serial0` não existe | UART GPIO ainda não habilitada | Habilitar UART e remover console serial antes do teste físico |
| FPS < 2 no RPi 4 | Modelo muito pesado | Reduzir `input_size` para 160x160 |
| `ImportError: No module named 'cv2'` | OpenCV não instalado | `sudo apt install python3-opencv` |
| Decisão não muda | `send_only_on_change: true` | Normal - só loga quando muda |

---

## Próximos Passos (Pós-POC)

1. **Otimização**: TensorRT / TFLite / NCNN para inferência mais rápida
2. **Controle avançado**: PID para direção suave, controle de velocidade
3. **Múltiplas classes**: Detectar `bottle`, `cup`, `container` (lixo flutuante)
4. **Telemetria avançada**: persistência histórica, bússola e calibração dos sensores de água
5. **Missão**: Waypoints, retorno à base, evasão de obstáculos
6. **Deploy**: systemd service, Docker, OTA updates
