# Sensores Ecoflutuador V4

A etapa HC-SR04 substitui o planejamento anterior: START usa TRIG 33/ECHO 32;
HW-870 passa para a entrada da rede no GPIO 25. ST100 anal?gico permanece no 35.

- [Pinagem vigente](PINAGEM_V4.md)
- [Configura??o, protocolo e roteiro sem motores](TESTE_V4_HCSR04.md)
- [Estrutura e altera??es do projeto](ESTRUTURA_V4.md)

GPS, pH, turbidez, UART Raspberry e motores preservam os pinos anteriores.
O ECHO requer o divisor resistivo externo previsto para 3,3 V.
O firmware padr?o de teste n?o faz attach nos ESCs.
